# Building Nexus Chat for Android (.apk)

Good news — unlike iOS, **Android Studio runs natively on Windows**, so both your
laptops can build this directly. No cloud rental, no borrowing anyone's computer.

## What this actually is

A native Android app that shows nexuschat.win full-screen (via WebView), plus real
Kotlin code for native notifications:

- **New message while the app is open** → a normal Android notification, like Discord.
- **Someone starts a call** → a notification with **Join** and **Dismiss** buttons,
  plus a ringtone that loops (rings, pauses, rings again) until you answer it or it
  times out. Tapping Join actually joins the call in the app.

**Honest limitation** (same as the Windows and iOS builds): this only notifies while
the app is open or was very recently open. It can't ring you hours later like a real
phone call — that needs Firebase Cloud Messaging (a real push server), which is a
separate, bigger project. Ask if you want that built later.

---

## Step 1: Install Android Studio (free)

1. Go to **https://developer.android.com/studio**
2. Download and run the Windows installer
3. Open Android Studio, click through the setup wizard (defaults are fine) — it'll
   download the Android SDK, give it a few minutes

## Step 2: Open the project

1. Unzip `NexusChatAndroid.zip` somewhere (e.g. Desktop)
2. In Android Studio: **File → Open** → select the unzipped `NexusChatAndroid` folder
3. Android Studio will start **"Gradle Sync"** — a progress bar at the bottom. This
   downloads all the pieces the project needs. **First time can take 5-15 minutes**
   depending on your internet — just let it run.

> If you see a popup about the **Gradle wrapper** being missing or needing a fix,
> click **OK** / **Use Gradle from: 'gradle-wrapper.properties' file** — this is
> normal and Android Studio handles it automatically.

## Step 3: Run it

1. Plug your Android phone into the laptop with a USB cable
2. On your phone, if asked, allow **USB debugging** (if this is the first time,
   you may need to enable Developer Options first: **Settings → About Phone** →
   tap **Build Number** 7 times → go back → **Developer Options** → enable
   **USB Debugging**)
3. Back in Android Studio, top toolbar has a device dropdown — select your phone
4. Click the green ▶ **Run** button

The app installs and opens on your phone directly. That's it for testing.

(No phone handy? Android Studio can also create a virtual phone: **Device
Manager** icon in the right sidebar → **Create Device** → pick any phone → pick a
system image → **Run**.)

---

## Step 4: Build the actual `.apk` file to hand out

1. Top menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Wait for it to finish — a notification pops up bottom-right saying
   "APK(s) generated successfully"
3. Click **locate** in that notification, or find it yourself at:
   `NexusChatAndroid\app\build\outputs\apk\debug\app-debug.apk`

That single `.apk` file is what you send people. To install it, they:
1. Transfer the file to their phone (email, USB, cloud drive, whatever)
2. Tap it — Android will ask to allow "install from this source" the first
   time, since it's not from the Play Store — they tap **Allow** then **Install**

## Step 5 (optional): Make it installable without warnings — sign a release build

The debug APK above works fine for friends/testing, but shows as "unverified" more
aggressively than a properly signed one. To do it properly:

1. Top menu: **Build → Generate Signed Bundle / APK** → choose **APK** → Next
2. Click **Create new...** to make a signing key (a file that proves the app is
   really from you across updates) — fill in the form, remember the passwords,
   **keep the resulting `.jks` file safe** — you'll need the exact same one for
   every future update of this app
3. Choose **release** build variant → Finish
4. Find the signed APK at `app/release/app-release.apk`

## Step 6 (optional): Publish to the Google Play Store

Needs a one-time **$25 USD** Google Play Developer account
(play.google.com/console). Upload the signed APK/AAB there, fill in the store
listing, submit for review. This is Google's process, not something to route
around.

---

## Changing things

- **Different website URL:** `app/src/main/java/win/nexuschat/app/MainActivity.kt`,
  the `appUrl` constant near the top.
- **Different icon:** replace the PNGs in `app/src/main/res/mipmap-*/` with your
  own (keep the same filenames), or ask me to generate a different design.
- **App name:** `app/src/main/res/values/strings.xml`, the `app_name` string.
