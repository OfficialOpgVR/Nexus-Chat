# Add project specific ProGuard rules here.
# minifyEnabled is off by default for this project (see app/build.gradle),
# so this file isn't used unless you turn it on.
