package win.nexuschat.app

import android.content.Context
import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * Exposed to the page as window.AndroidBridge (see MainActivity's
 * addJavascriptInterface call). The website's own JS bridge code
 * (the "NATIVE APP BRIDGE" section in NexusChat.html) posts JSON strings here
 * via window.AndroidBridge.postMessage(...) - mirroring the same pattern used
 * for window.chrome.webview on the Windows build and window.webkit.messageHandlers
 * on iOS, just with Android's naming.
 */
class WebAppInterface(private val context: Context) {

    @JavascriptInterface
    fun postMessage(json: String) {
        try {
            val obj = JSONObject(json)
            when (obj.optString("type")) {
                "message" -> NotificationHelper.showMessageNotification(
                    context,
                    obj.optString("title", "Nexus Chat"),
                    obj.optString("body", "")
                )
                "call" -> NotificationHelper.showIncomingCallNotification(
                    context,
                    obj.optString("callId", ""),
                    obj.optString("title", "Call"),
                    obj.optString("caller", "Someone")
                )
                "callEnded" -> NotificationHelper.clearCallNotification(context)
            }
        } catch (_: Exception) {
            // Malformed message from the page - ignore rather than crash.
        }
    }
}
