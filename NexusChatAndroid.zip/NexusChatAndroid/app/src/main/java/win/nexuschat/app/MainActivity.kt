package win.nexuschat.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    // ---- Change this if your site ever moves to a different domain. ----
    private val appUrl = "https://nexuschat.win"

    private lateinit var webView: WebView

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { /* results handled implicitly - WebView re-checks on next getUserMedia call */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NotificationHelper.ensureChannels(this)
        requestRuntimePermissions()

        webView = findViewById(R.id.webView)
        val splash = findViewById<View>(R.id.splash)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            @Suppress("DEPRECATION")
            databaseEnabled = true
        }

        webView.addJavascriptInterface(WebAppInterface(this), "AndroidBridge")
        WebBridge.webView = webView

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                splash.visibility = View.GONE
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // Auto-approve mic/camera for our own domain only, so calls work without
            // a confusing extra in-page permission prompt on top of the real Android
            // system permission dialog (which still appears the first time - that one
            // is required and this does not bypass it).
            override fun onPermissionRequest(request: PermissionRequest) {
                val origin = request.origin.toString()
                if (origin.startsWith(appUrl)) {
                    runOnUiThread { request.grant(request.resources) }
                } else {
                    runOnUiThread { request.deny() }
                }
            }
        }

        webView.loadUrl(appUrl)
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.CAMERA)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.POST_NOTIFICATIONS)

        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }

    override fun onDestroy() {
        NotificationHelper.clearCallNotification(this)
        super.onDestroy()
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
