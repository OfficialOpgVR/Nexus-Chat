package win.nexuschat.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat

/**
 * Local notifications only - no push server involved. That means this works
 * while the app is running or recently backgrounded, same honest limitation as
 * the Windows and iOS builds. True "ring even hours after the phone was locked"
 * behaviour needs Firebase Cloud Messaging (a real push server), which is a
 * bigger separate project - ask if you want that built later.
 */
object NotificationHelper {

    private const val CHANNEL_MESSAGES = "nexus_messages"
    private const val CHANNEL_CALLS = "nexus_calls"
    const val CALL_NOTIFICATION_ID = 4200

    private var ringtonePlayer: MediaPlayer? = null
    private val stopHandler = Handler(Looper.getMainLooper())
    private var stopRunnable: Runnable? = null

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java)

        if (nm.getNotificationChannel(CHANNEL_MESSAGES) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_MESSAGES, "Messages", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "New message notifications"
                }
            )
        }
        if (nm.getNotificationChannel(CHANNEL_CALLS) == null) {
            nm.createNotificationChannel(
                // Sound is muted at the channel level on purpose - we play the
                // looping ringtone ourselves via MediaPlayer so it can actually
                // repeat, rather than the single one-shot sound a channel allows.
                NotificationChannel(CHANNEL_CALLS, "Incoming Calls", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Incoming call alerts"
                    setSound(null, null)
                    enableVibration(true)
                }
            )
        }
    }

    fun showMessageNotification(context: Context, title: String, body: String) {
        val notif = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        androidx.core.app.NotificationManagerCompat.from(context)
            .notify(System.currentTimeMillis().toInt(), notif)
    }

    fun showIncomingCallNotification(context: Context, callId: String, title: String, caller: String) {
        clearCallNotification(context)

        val joinIntent = Intent(context, CallActionReceiver::class.java).apply {
            action = CallActionReceiver.ACTION_JOIN
            putExtra(CallActionReceiver.EXTRA_CALL_ID, callId)
        }
        val dismissIntent = Intent(context, CallActionReceiver::class.java).apply {
            action = CallActionReceiver.ACTION_DISMISS
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val joinPending = PendingIntent.getBroadcast(context, 1, joinIntent, flags)
        val dismissPending = PendingIntent.getBroadcast(context, 2, dismissIntent, flags)

        val notif = NotificationCompat.Builder(context, CHANNEL_CALLS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Incoming Call - $title")
            .setContentText("$caller is calling...")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setAutoCancel(false)
            .addAction(0, "Join", joinPending)
            .addAction(0, "Dismiss", dismissPending)
            .setContentIntent(joinPending)
            .build()

        androidx.core.app.NotificationManagerCompat.from(context).notify(CALL_NOTIFICATION_ID, notif)
        startRingtone(context)
    }

    fun clearCallNotification(context: Context) {
        androidx.core.app.NotificationManagerCompat.from(context).cancel(CALL_NOTIFICATION_ID)
        stopRingtone()
    }

    private fun startRingtone(context: Context) {
        stopRingtone()
        try {
            val player = MediaPlayer()
            val afd = context.resources.openRawResourceFd(R.raw.ringtone)
            player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            player.isLooping = true // the WAV itself contains ring + silence, so looping = "rings, pauses, rings again"
            player.prepare()
            player.start()
            ringtonePlayer = player
        } catch (_: Exception) {
            // Non-fatal - the visible/actionable notification still works even if audio fails.
        }

        // Matches the 30s auto-timeout already used on the web side.
        stopRunnable = Runnable { stopRingtone() }.also {
            stopHandler.postDelayed(it, 30_000)
        }
    }

    private fun stopRingtone() {
        stopRunnable?.let { stopHandler.removeCallbacks(it) }
        stopRunnable = null
        ringtonePlayer?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        ringtonePlayer = null
    }
}
