package win.nexuschat.app

import android.webkit.WebView
import java.lang.ref.WeakReference

/**
 * Holds a weak reference to the live WebView so CallActionReceiver (which has no
 * view hierarchy of its own - it's just a broadcast receiver) can inject JS back
 * into the page when the user taps "Join" or "Dismiss" on the call notification.
 */
object WebBridge {
    private var ref: WeakReference<WebView>? = null

    var webView: WebView?
        get() = ref?.get()
        set(value) { ref = WeakReference(value) }

    fun runCommand(action: String, callId: String? = null) {
        val wv = webView ?: return
        val js = if (callId != null)
            "window.nexusNativeCommand && window.nexusNativeCommand('$action', '$callId');"
        else
            "window.nexusNativeCommand && window.nexusNativeCommand('$action');"
        wv.post { wv.evaluateJavascript(js, null) }
    }
}
