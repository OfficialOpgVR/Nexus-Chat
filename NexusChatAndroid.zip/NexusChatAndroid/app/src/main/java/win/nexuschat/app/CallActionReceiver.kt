package win.nexuschat.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Fires when the user taps "Join" or "Dismiss" on the incoming-call notification.
 * Routes the action back into the running page via WebBridge, which calls the
 * same window.nexusNativeCommand(...) function the Windows and iOS builds use.
 */
class CallActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_JOIN = "win.nexuschat.app.ACTION_JOIN_CALL"
        const val ACTION_DISMISS = "win.nexuschat.app.ACTION_DISMISS_CALL"
        const val EXTRA_CALL_ID = "callId"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_JOIN -> {
                val callId = intent.getStringExtra(EXTRA_CALL_ID)
                WebBridge.runCommand("joinCall", callId)
            }
            ACTION_DISMISS -> {
                WebBridge.runCommand("dismissCall")
            }
        }
        NotificationHelper.clearCallNotification(context)
    }
}
