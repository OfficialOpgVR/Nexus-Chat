# Building Nexus Chat for iOS (.ipa)

**The honest part first:** Xcode (Apple's build tool) only runs on macOS. There is
no way around this — it's not a limitation of this project, it's Apple's rule. Since
you only have Windows laptops + an iPhone, you have two real options:

1. **Rent a cloud Mac** — e.g. **MacinCloud** (macincloud.com) or **MacStadium**,
   roughly $20-30/month, cancel anytime. You get a real macOS desktop in your
   browser with Xcode installable on it. This is the standard way people without
   a Mac build iOS apps.
2. **Borrow a Mac for an afternoon** — a friend's, a library, a school computer
   lab. You only need it for the "Build Step" below; once it's built, the app
   lives on your iPhone.

Everything in this folder is ready to go the moment you're on a Mac — you don't
need to write or fix any code.

---

## What this actually is

A native iPhone/iPad app that shows nexuschat.win full-screen (via WKWebView, the
same engine Safari uses), plus real Swift code for native notifications:

- **New message while the app is open** → a real iOS notification banner, like Discord.
- **Someone starts a call** → a notification with **Join** and **Dismiss** buttons,
  plus a ringtone that plays on a loop (rings, pauses, rings again) until you
  answer it. Tapping **Join** actually joins the call — it sends a real command
  into the app, not just "open the app and hope."

**Honest limitation:** like the Windows version, this only notifies while the app
is open or was very recently open — it can't ring you hours later while your phone
was locked, the way a real phone call does. That needs Apple's VoIP Push
(PushKit + CallKit + your own push server), which is a much bigger separate
project — ask me if you want that built later.

---

## Step 1: Get on a Mac

Pick option 1 or 2 above. Once you're at a macOS desktop:

1. Open the **App Store** app → search **Xcode** → **Get** (it's free, but it's a
   big download — a few GB, give it time)

## Step 2: Open the project

1. Unzip `NexusChatIOS.zip`
2. Double-click **`NexusChatIOS.xcodeproj`** — it opens in Xcode

## Step 3: Sign in with your Apple ID (free, no paid account needed for this step)

1. In Xcode's menu: **Xcode → Settings → Accounts**
2. Click **+** → **Apple ID** → sign in with any Apple ID (the same one on your
   iPhone is easiest)
3. Close Settings

## Step 4: Run it on your iPhone

1. Plug your iPhone into the Mac with a cable
2. On your iPhone, if asked, tap **Trust This Computer**
3. In Xcode's top toolbar, click the device dropdown (probably says "Any iOS
   Device" or a simulator name) → pick **your iPhone** from the list
4. Click the ▶ Play button

**The first time**, your iPhone will refuse to open the app with an "Untrusted
Developer" message. Fix that once:
- On your iPhone: **Settings → General → VPN & Device Management**
- Tap your Apple ID under "Developer App" → **Trust**

Run it from Xcode again (▶) and it'll open properly this time.

> With a completely free Apple ID (no $99/year Developer Program), the app stays
> installed for **7 days** before it needs re-signing from Xcode (just plug in and
> hit ▶ again). If you want it to just work indefinitely without reconnecting to a
> Mac every week, that requires Apple's paid Developer Program
> (developer.apple.com, $99/year) — genuinely Apple's rule, not something I can
> route around.

---

## Building a distributable `.ipa` file instead

If you want an actual `.ipa` file (e.g. to install without a cable, via a service
like Diawi, or to submit to TestFlight/App Store), you need the paid Apple
Developer Program membership mentioned above. Once you have it:

1. In Xcode: select the project in the left sidebar → **Signing & Capabilities**
   → make sure your paid team is selected
2. **Product → Archive**
3. When the Organizer window opens, click **Distribute App** → choose
   **Ad Hoc** (install on specific devices) or **App Store Connect** (for
   TestFlight/App Store) → follow the prompts
4. Xcode produces the `.ipa` at the end

---

## Changing things

- **Different website URL:** open `WebViewContainer.swift`, change the `appURL`
  constant near the top.
- **Different icon:** replace `Assets.xcassets/AppIcon.appiconset/icon-1024.png`
  with your own 1024×1024 PNG (must have no transparency), or ask me to generate
  a different design.
- **App name shown under the icon:** in Xcode, project settings → General →
  Display Name (currently "Nexus Chat").
