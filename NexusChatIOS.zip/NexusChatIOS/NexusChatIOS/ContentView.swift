import SwiftUI

struct ContentView: View {
    @State private var isLoading = true

    var body: some View {
        ZStack {
            Color(red: 10/255, green: 11/255, blue: 13/255)
                .ignoresSafeArea()

            WebViewContainer(isLoading: $isLoading)
                .ignoresSafeArea()

            if isLoading {
                VStack(spacing: 10) {
                    Text("NEXUS")
                        .font(.system(size: 34, weight: .bold, design: .monospaced))
                        .foregroundColor(.white)
                    Text("Starting up...")
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 154/255, green: 161/255, blue: 172/255))
                }
                .transition(.opacity)
            }
        }
        .onAppear {
            NotificationManager.shared.requestPermission()
        }
    }
}

#Preview {
    ContentView()
}
