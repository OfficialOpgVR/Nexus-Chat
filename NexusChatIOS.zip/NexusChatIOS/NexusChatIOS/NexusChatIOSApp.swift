import SwiftUI
import UserNotifications

@main
struct NexusChatIOSApp: App {
    // Registers our AppDelegate so we can set the notification delegate before
    // any notification-related UI shows up (required for the "Join"/"Dismiss"
    // buttons on the incoming-call notification to actually work).
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        NotificationManager.shared.configure()
        return true
    }
}
