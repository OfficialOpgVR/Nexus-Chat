import Foundation
import UserNotifications
import AVFoundation

/// Local notifications only - no push server involved. That means this works
/// while the app is running or recently backgrounded, same honest limitation as
/// the Windows desktop build. True "ring even when the phone's been locked for
/// hours" behaviour needs Apple's VoIP Push (PushKit + CallKit + a push server),
/// which is a much bigger, separate project - ask if you want that built later.
final class NotificationManager: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationManager()

    private let callCategoryId = "INCOMING_CALL"
    private let callRequestId = "nexus-incoming-call"
    private var ringtonePlayer: AVAudioPlayer?
    private var ringtoneStopTimer: Timer?

    func configure() {
        UNUserNotificationCenter.current().delegate = self

        let joinAction = UNNotificationAction(
            identifier: "JOIN_CALL",
            title: "Join",
            options: [.foreground]
        )
        let dismissAction = UNNotificationAction(
            identifier: "DISMISS_CALL",
            title: "Dismiss",
            options: [.destructive]
        )
        let callCategory = UNNotificationCategory(
            identifier: callCategoryId,
            actions: [joinAction, dismissAction],
            intentIdentifiers: [],
            options: [.customDismissAction]
        )
        UNUserNotificationCenter.current().setNotificationCategories([callCategory])

        try? AVAudioSession.sharedInstance().setCategory(.playback, options: [.mixWithOthers])
    }

    func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    // MARK: - Showing notifications

    func showMessageNotification(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: nil // deliver immediately
        )
        UNUserNotificationCenter.current().add(request)
    }

    func showIncomingCallNotification(callId: String, title: String, caller: String) {
        clearCallNotification()

        let content = UNMutableNotificationContent()
        content.title = "Incoming Call - \(title)"
        content.body = "\(caller) is calling..."
        content.categoryIdentifier = callCategoryId
        content.userInfo = ["callId": callId]
        content.sound = nil // we play our own looping ringtone instead of a single ding

        let request = UNNotificationRequest(identifier: callRequestId, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)

        startRingtone()
    }

    func clearCallNotification() {
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [callRequestId])
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [callRequestId])
        stopRingtone()
    }

    // MARK: - Ringtone (synthesised in-app, no bundled audio file needed)

    private func startRingtone() {
        stopRingtone()
        do {
            try AVAudioSession.sharedInstance().setActive(true)
            let data = RingtoneSynth.makeRingPattern()
            let player = try AVAudioPlayer(data: data)
            player.numberOfLoops = -1 // the WAV itself contains ring + silence, so looping = "rings, pauses, rings again"
            player.volume = 0.9
            player.play()
            ringtonePlayer = player
        } catch {
            // Non-fatal - the visible/actionable notification still works even if audio fails.
        }

        // Matches the 30s auto-timeout already used on the web side.
        ringtoneStopTimer = Timer.scheduledTimer(withTimeInterval: 30, repeats: false) { [weak self] _ in
            self?.stopRingtone()
        }
    }

    private func stopRingtone() {
        ringtonePlayer?.stop()
        ringtonePlayer = nil
        ringtoneStopTimer?.invalidate()
        ringtoneStopTimer = nil
    }

    // MARK: - UNUserNotificationCenterDelegate

    /// Lets the banner + sound show even while the app is in the foreground
    /// (by default iOS suppresses that unless you opt in here).
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound, .badge])
    }

    /// Fires when the user taps the notification body, or one of the Join/Dismiss buttons.
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        let callId = response.notification.request.content.userInfo["callId"] as? String

        switch response.actionIdentifier {
        case "JOIN_CALL":
            WebBridge.shared.runCommand(action: "joinCall", callId: callId)
        case "DISMISS_CALL", UNNotificationDismissActionIdentifier:
            WebBridge.shared.runCommand(action: "dismissCall")
        case UNNotificationDefaultActionIdentifier:
            // Plain tap on the notification body - just bring the app forward;
            // if it was the call notification, also open the join flow.
            if response.notification.request.identifier == callRequestId {
                WebBridge.shared.runCommand(action: "joinCall", callId: callId)
            }
        default:
            break
        }

        clearCallNotification()
        completionHandler()
    }
}

/// Generates a short "ring, then quiet, then ring again" WAV clip at runtime -
/// no bundled audio asset required. Two gentle sine-wave notes per ring,
/// matching the same motif as the web app's own ringtone.
enum RingtoneSynth {
    static func makeRingPattern() -> Data {
        let sampleRate = 44100.0
        let ringDuration = 0.9
        let silenceDuration = 1.6
        let totalDuration = ringDuration + silenceDuration
        let sampleCount = Int(sampleRate * totalDuration)

        var samples = [Int16](repeating: 0, count: sampleCount)
        let ringSamples = Int(sampleRate * ringDuration)

        for i in 0..<ringSamples {
            let t = Double(i) / sampleRate
            // Two-tone chime, second note slightly delayed, both with a soft envelope.
            let noteA = sin(2.0 * .pi * 523.25 * t)
            let noteB = t > 0.12 ? sin(2.0 * .pi * 659.25 * (t - 0.12)) : 0
            let envelope = min(1.0, t * 12) * max(0, 1.0 - (t / ringDuration))
            let sample = (noteA * 0.5 + noteB * 0.5) * envelope * 0.6
            samples[i] = Int16(max(-32767, min(32767, sample * 32767)))
        }
        // Remaining samples stay at 0 (silence) for the pause between rings.

        return wavData(from: samples, sampleRate: Int(sampleRate))
    }

    private static func wavData(from samples: [Int16], sampleRate: Int) -> Data {
        var data = Data()
        let byteRate = sampleRate * 2
        let dataSize = samples.count * 2

        func append(_ s: String) { data.append(s.data(using: .ascii)!) }
        func appendLE(_ v: UInt32) {
            data.append(UInt8(v & 0xff)); data.append(UInt8((v >> 8) & 0xff))
            data.append(UInt8((v >> 16) & 0xff)); data.append(UInt8((v >> 24) & 0xff))
        }
        func appendLE16(_ v: UInt16) {
            data.append(UInt8(v & 0xff)); data.append(UInt8((v >> 8) & 0xff))
        }

        append("RIFF"); appendLE(UInt32(36 + dataSize)); append("WAVE")
        append("fmt "); appendLE(16); appendLE16(1); appendLE16(1)
        appendLE(UInt32(sampleRate)); appendLE(UInt32(byteRate))
        appendLE16(2); appendLE16(16)
        append("data"); appendLE(UInt32(dataSize))
        for s in samples { appendLE16(UInt16(bitPattern: s)) }
        return data
    }
}
