import SwiftUI
import WebKit

/// Holds a weak reference to the live WKWebView so NotificationManager (which
/// has no view hierarchy of its own) can inject JS back into the page when the
/// user taps "Join" or "Dismiss" on a notification.
final class WebBridge {
    static let shared = WebBridge()
    weak var webView: WKWebView?

    func runCommand(action: String, callId: String? = nil) {
        let js: String
        if let callId = callId {
            js = "window.nexusNativeCommand && window.nexusNativeCommand('\(action)', '\(callId)');"
        } else {
            js = "window.nexusNativeCommand && window.nexusNativeCommand('\(action)');"
        }
        DispatchQueue.main.async {
            self.webView?.evaluateJavaScript(js, completionHandler: nil)
        }
    }
}

struct WebViewContainer: UIViewRepresentable {
    // ---- Change this if your site ever moves to a different domain. ----
    static let appURL = URL(string: "https://nexuschat.win")!

    @Binding var isLoading: Bool

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> WKWebView {
        let contentController = WKUserContentController()
        contentController.add(context.coordinator, name: "nexusBridge")

        let config = WKWebViewConfiguration()
        config.userContentController = contentController
        // Calls need audio/video to play without a tap-to-play gate, same as a
        // real calling app.
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.scrollView.bounces = false
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 10/255, green: 11/255, blue: 13/255, alpha: 1)

        WebBridge.shared.webView = webView
        webView.load(URLRequest(url: Self.appURL))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        let parent: WebViewContainer
        init(_ parent: WebViewContainer) { self.parent = parent }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async { self.parent.isLoading = false }
        }

        // Auto-approve mic/camera prompts for our own domain only, so calls work
        // without WKWebView's generic system permission sheet getting in the way
        // (the OS-level mic/camera permission prompt still appears the FIRST time,
        // that's a separate, required privacy prompt this doesn't bypass).
        @available(iOS 15.0, *)
        func webView(
            _ webView: WKWebView,
            requestMediaCapturePermissionFor origin: WKSecurityOrigin,
            initiatedByFrame frame: WKFrameInfo,
            type: WKMediaCaptureType,
            decisionHandler: @escaping (WKPermissionDecision) -> Void
        ) {
            if origin.host.contains("nexuschat.win") {
                decisionHandler(.grant)
            } else {
                decisionHandler(.deny)
            }
        }

        // Messages posted from the website via
        // window.webkit.messageHandlers.nexusBridge.postMessage(...)
        // (see the "NATIVE APP BRIDGE" section in NexusChat.html) land here.
        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage
        ) {
            guard let jsonString = message.body as? String,
                  let data = jsonString.data(using: .utf8),
                  let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let type = obj["type"] as? String
            else { return }

            switch type {
            case "message":
                NotificationManager.shared.showMessageNotification(
                    title: obj["title"] as? String ?? "Nexus Chat",
                    body: obj["body"] as? String ?? "")

            case "call":
                NotificationManager.shared.showIncomingCallNotification(
                    callId: obj["callId"] as? String ?? "",
                    title: obj["title"] as? String ?? "Call",
                    caller: obj["caller"] as? String ?? "Someone")

            case "callEnded":
                NotificationManager.shared.clearCallNotification()

            default:
                break
            }
        }
    }
}
